﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine("🌍 === Generando Mapa de Tráfico === 🌍");

        // ===== Crear carpeta "datos" una carpeta atrás =====
        string parentFolder = Directory.GetParent(Environment.CurrentDirectory).FullName;
        string folder = Path.Combine(parentFolder, "datos");
        Directory.CreateDirectory(folder);
        Console.WriteLine($"📂 Carpeta de datos creada en: {folder}");

        // ===== Grafo No Dirigido (Calles Bidireccionales) =====
        var undirected = new Graph<string>();
        Console.WriteLine("\n🛣️ Agregando calles bidireccionales...");

        undirected.AddEdge("A", "B", 4.0, false);
        undirected.AddEdge("A", "C", 3.2, false);
        undirected.AddEdge("B", "D", 10.0, false);
        undirected.AddEdge("C", "E", 2.8, false);
        undirected.AddEdge("D", "F", 7.0, false);
        undirected.AddEdge("E", "F", 2.5, false);
        undirected.AddEdge("G", "H", 2.5, false);

        undirected.ExportToFile(Path.Combine(folder, "edges_undirected.txt"), includeWeights: true, deduplicateUndirected: true);

        // ===== Grafo Dirigido (Calles Unidireccionales) =====
        var directed = new Graph<string>();
        Console.WriteLine("\n🚦 Creando mapa completo con calles direccionales...");

        directed.AddEdge("A", "G", 1.0, true);
        directed.AddEdge("B", "H", 10.0, true);
        directed.AddEdge("C", "D", 2.0, true);
        directed.AddEdge("F", "E", 3.5, true);
        directed.AddEdge("H", "A", 6.5, true);
        directed.AddEdge("A", "E", 6.0, true);
        directed.AddEdge("B", "F", 3.7, true);
        directed.AddEdge("C", "G", 2.8, true);
        directed.AddEdge("D", "H", 2.2, true);
        directed.AddEdge("E", "B", 5.0, true);

        directed.ExportToFile(Path.Combine(folder, "edges_directed.txt"), includeWeights: true, deduplicateUndirected: false);

        // ===== Pruebas de funcionalidad =====
        Console.WriteLine("\n🧪 === Pruebas de Funcionalidad ===");
        Console.WriteLine($"Grado de A (no dirigido): {undirected.GetOutDegree("A")} (esperado: 2)");
        Console.WriteLine($"¿Existe A↔B no dirigido? {undirected.HasEdge("A", "B")} (esperado: True)");
        Console.WriteLine($"¿Existe B↔A no dirigido? {undirected.HasEdge("B", "A")} (esperado: True)");

        Console.WriteLine($"\nGrado salida A (dirigido): {directed.GetOutDegree("A")}");
        Console.WriteLine($"Grado entrada A (dirigido): {directed.GetInDegree("A")}");
        Console.WriteLine($"¿Existe A→G dirigido? {directed.HasEdge("A", "G")} (esperado: True)");
        Console.WriteLine($"¿Existe G→A dirigido? {directed.HasEdge("G", "A")} (esperado: False)");

        Console.WriteLine("\n🎉 ¡Proyecto C# completado exitosamente!");
    }
}
