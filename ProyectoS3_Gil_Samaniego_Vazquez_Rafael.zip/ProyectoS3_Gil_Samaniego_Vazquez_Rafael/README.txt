======= PASOS PARA INSTALAR EL COMPILADOR DE C# =======
1- Descargas SDK de .NET en este link https://dotnet.microsoft.com/en-us/download/visual-studio-sdks
2- Para correr archivos necesitas posicionarte en la terminal en la carpeta de el proyecto.
3- Escribir "dotnet run + 'nombre_del_archivo.cs'", con esto se compilara el codigo en la terminal.
4- Instalar la extencion de .NET Install Tool en VsCode.
5- Instalar la extencion de C# en VsCode.


======= PASOS PARA INSTALAR EL COMPILADOR DE PYTHON =======
1- Descargar python3 en este link https://www.python.org/
2- Para correr archivos necesitas posicionarte en la terminal en la carpeta de el proyecto.
3- Escrbir "python3 + 'nombre_del_archivo.py'"
4- Instalar la extencion de Python en VsCode.
5- Instalar la extencion de Python Debugger en VsCode.



======= PASOS PARA COMPILAR EL PROYECTO =======
1- Se necesita introducir el grafo en el archivo "Program.cs", eligiendo asi el nodo dependiendo si es dirigido o no dirigido, de origen a destino y su distancia en decimal(km).
2- Una vez en la carpeta proyecto, deebera abrir la carpeta codigo escribiendo "cd .\ProyectoS3_Gil_Samaniego_Vazquez_Rafael\codigo\".
3- Escribir el comando dotnet run hara que se ejecuten ambos programas de C# ya que estos al ser un proyecto solo basta con ese comando.
3- Se creara la carpeta "datos" fuera de la carpeta de codigo y  dentro de ella estaran los archivos "edges_undirected" (aristas no dirigidas) y "edges_directed" (aristas dirigidas).
4- Seguido de esto debe escribir en la terminal dentro del proyecto "python .\analisis.py" y ejecutarlo, esto correra el codigo de python dandonos asi las estadisticas generales, detalles por vertice y las pruebas de conectividad.
