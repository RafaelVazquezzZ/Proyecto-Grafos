import heapq
import math
from collections import defaultdict
from typing import Dict, List, Tuple

class WeightedGraph:
    def __init__(self, n: int):
        self.n = n
        self.adj = {i: [] for i in range(n)}
    
    def add_edge(self, u: int, v: int, w: float):
        self.adj[u].append((v, w))
        # Para no dirigido: self.adj[v].append((u, w))
    
    # Dijkstra
    def dijkstra(self, src: int) -> Tuple[List[float], List[int]]:
        dist = [math.inf] * self.n
        parent = [-1] * self.n
        dist[src] = 0
        pq = [(0, src)]  # (dist, node)
        visited = [False] * self.n
        
        while pq:
            cost, u = heapq.heappop(pq)
            if visited[u]: continue
            visited[u] = True
            
            for v, w in self.adj[u]:
                if dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    parent[v] = u
                    heapq.heappush(pq, (dist[v], v))
        
        return dist, parent
    
    # Floyd-Warshall
    def floyd_warshall(self) -> List[List[float]]:
        if self.n == 0: #Correcion para que funcionara el codigo y completara los 10 test.
            raise ValueError("No se puede ejecutar Floyd-Warshall en un grafo vacio.")
        dist = [[math.inf] * self.n for _ in range(self.n)]
        for i in range(self.n):
            dist[i][i] = 0
        
        for u in range(self.n):
            for v, w in self.adj[u]:
                dist[u][v] = w
        
        for k in range(self.n):
            for i in range(self.n):
                for j in range(self.n):
                    if dist[i][k] + dist[k][j] < dist[i][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]
        
        # Detectar ciclos negativos
        for i in range(self.n):
            if dist[i][i] < 0:
                raise ValueError("Ciclo negativo detectado")
        
        return dist

# Ejemplo de uso
if __name__ == "__main__":
    g = WeightedGraph(6)
    g.add_edge(0,1,10); g.add_edge(0,2,5)
    g.add_edge(1,3,3); g.add_edge(2,3,2); g.add_edge(2,4,8)
    g.add_edge(3,4,4); g.add_edge(1,5,15); g.add_edge(4,5,7)

if __name__ == "__main__":
    
    # Ejemplo de Uso y Análisis para el Reporte (10 Nodos)-
    
    # 1 Creación del Grafo Urbano
    g = WeightedGraph(10)

    # Nodos: 0=Plaza Central, 1=Comercial, 2=Hospital, 3=Universidad, 
    #        4=Bifurcación, 5=Logística, 6=Residencial, 7=Puente Crítico, 9=Destino Final

    # Aristas de Conexión y Trayectoria con Peso
    g.add_edge(0, 1, 5)     
    g.add_edge(0, 2, 12)
    g.add_edge(0, 4, 15)

    g.add_edge(1, 2, 2)     # Ruta rapida (Comercial -> Hospital)
    g.add_edge(1, 4, 10)    # ARISTA CRÍTICA (Simulación de cierre/tráfico)

    g.add_edge(2, 3, 6)
    g.add_edge(2, 5, 18)    

    g.add_edge(3, 5, 4)     # Ruta corta (Universidad -> Logística)
    g.add_edge(3, 7, 8)
    g.add_edge(3, 6, 20)

    g.add_edge(4, 6, 3)
    g.add_edge(5, 7, 7)
    
    g.add_edge(7, 9, 2)     # Conexión al Destino Final
    g.add_edge(6, 9, 15)
    
    
    # 2 Ejecución de Dijkstra (De Plaza a Destino)
    
    dist, parent = g.dijkstra(0)
    
    # Reconstruir el camino óptimo
    shortest_path_0_to_9 = g.reconstruct_path(parent, 9)
    
    print("--- Resultados de Dijkstra ---")
    print(f"Camino más corto (0 -> 9): {shortest_path_0_to_9}")
    print(f"Costo Mínimo (0 -> 9): {dist[9]:.1f} min")


    # 3 Ejecución de Floyd-Warshall
    
    fw = g.floyd_warshall()
    print("\n--- Resultados de Floyd-Warshall (Distancia 0 -> 9) ---")
    print(f"FW Distancia (0 -> 9): {fw[0][9]:.1f} min")

    dist, parent = g.dijkstra(0)
    print(f"Dist a F: {dist[5]}")  # 18

    fw = g.floyd_warshall()
    print(f"FW dist 0-5: {fw[0][5]}")  # 18