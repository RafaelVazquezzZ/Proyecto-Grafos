Semana 5 Grafos

- Alumno: Gil Samaniego Vázquez Rafael
- Módulo: Estructuras de Datos Avanzadas

INSTRUCCIONES DE EJECUCIÓN

==================================================
EJECUCIÓN DEL PROYECTO (Python)
==================================================

El archivo principal 'weighted_graph.py' contiene la clase WeightedGraph, los algoritmos Dijkstra y Floyd-Warshall, y el bloque de ejecución para el análisis y generación de datos del reporte (cálculos de ruta, simulación de tráfico y visualización).

PASOS PARA LA EJECUCIÓN:
1- Posicionarse en la terminal:
   Abre tu terminal y navega hasta la carpeta donde se encuentra el archivo 'weighted_graph.py'.
   
2- Ejecutar el script:
   Escribe el siguiente comando y presiona Enter:
   python weighted_graph.py

RESULTADOS DE LA EJECUCIÓN:
Se ejecutarán los cálculos de rutas óptimas (Baseline y Caso de Uso de Tráfico).
Se imprimirán los resultados de las distancias mínimas y caminos reconstruidos en la terminal.
Se generará la imagen del grafo 'reporte_grafo_optimo.png' en la misma carpeta para el reporte.
Para correr las pruebas unitarias, ejecuta: pytest weighted_graph.py
