using System;
using System.Collections.Generic;
using System.Linq;

namespace DataStructures.Week5
{
    /// <summary>
    /// Clase que implementa algoritmos de exploración y búsqueda en grafos.
    /// Incluye BFS, DFS (recursivo e iterativo), y aplicaciones prácticas.
    /// </summary>
    public class GraphTraversal
    {
        // Representación del grafo usando lista de adyacencia
        private Dictionary<int, List<int>> adjacencyList;
        
        /// <summary>
        /// Constructor: inicializa el grafo vacío.
        /// </summary>
        public GraphTraversal()
        {
            adjacencyList = new Dictionary<int, List<int>>();
        }
        
        /// <summary>
        /// Agrega una arista no dirigida entre dos nodos.
        /// </summary>
        public void AddEdge(int u, int v)
        {
            if (!adjacencyList.ContainsKey(u))
                adjacencyList[u] = new List<int>();
            if (!adjacencyList.ContainsKey(v))
                adjacencyList[v] = new List<int>();
            
            adjacencyList[u].Add(v);
            adjacencyList[v].Add(u);
        }
        
        /// <summary>
        /// Agrega una arista dirigida de u a v.
        /// </summary>
        public void AddDirectedEdge(int u, int v)
        {
            if (!adjacencyList.ContainsKey(u))
                adjacencyList[u] = new List<int>();
            
            adjacencyList[u].Add(v);
            
            // Asegurar que v existe en el grafo
            if (!adjacencyList.ContainsKey(v))
                adjacencyList[v] = new List<int>();
        }
        
        // ========================================
        // BÚSQUEDA EN AMPLITUD (BFS)
        // ========================================
        
        /// <summary>
        /// Realiza BFS desde un nodo inicial y retorna el orden de visita.
        /// Complejidad: O(V + E)
        /// </summary>
        /// <exception cref="ArgumentException">Si el nodo inicial no existe en el grafo</exception>
        public List<int> BFS(int start)
        {
            // Validación de caso límite: nodo inexistente
            if (!adjacencyList.ContainsKey(start))
                throw new ArgumentException($"El nodo {start} no existe en el grafo");
            
            var visited = new HashSet<int>();
            var result = new List<int>();
            var queue = new Queue<int>();
            
            queue.Enqueue(start);
            visited.Add(start);
            
            while (queue.Count > 0)
            {
                int current = queue.Dequeue();
                result.Add(current);
                
                // Explorar vecinos no visitados
                if (adjacencyList.ContainsKey(current))
                {
                    foreach (int neighbor in adjacencyList[current])
                    {
                        if (!visited.Contains(neighbor))
                        {
                            visited.Add(neighbor);
                            queue.Enqueue(neighbor);
                        }
                    }
                }
            }
            
            return result;
        }
        
        /// <summary>
        /// BFS que retorna distancias desde el nodo inicial.
        /// Útil para encontrar caminos más cortos en grafos no ponderados.
        /// </summary>
        public Dictionary<int, int> BFSDistances(int start)
        {
            var distances = new Dictionary<int, int>();
            var queue = new Queue<int>();
            
            queue.Enqueue(start);
            distances[start] = 0;
            
            while (queue.Count > 0)
            {
                int current = queue.Dequeue();
                
                if (adjacencyList.ContainsKey(current))
                {
                    foreach (int neighbor in adjacencyList[current])
                    {
                        if (!distances.ContainsKey(neighbor))
                        {
                            distances[neighbor] = distances[current] + 1;
                            queue.Enqueue(neighbor);
                        }
                    }
                }
            }
            
            return distances;
        }
        
        /// <summary>
        /// BFS que reconstruye el camino más corto de start a end.
        /// Retorna null si no hay camino.
        /// </summary>
        public List<int>? BFSShortestPath(int start, int end)
        {
            var parent = new Dictionary<int, int>();
            var visited = new HashSet<int>();
            var queue = new Queue<int>();
            
            queue.Enqueue(start);
            visited.Add(start);
            parent[start] = -1; // Sin padre
            
            bool found = false;
            
            while (queue.Count > 0 && !found)
            {
                int current = queue.Dequeue();
                
                if (current == end)
                {
                    found = true;
                    break;
                }
                
                if (adjacencyList.ContainsKey(current))
                {
                    foreach (int neighbor in adjacencyList[current])
                    {
                        if (!visited.Contains(neighbor))
                        {
                            visited.Add(neighbor);
                            parent[neighbor] = current;
                            queue.Enqueue(neighbor);
                        }
                    }
                }
            }
            
            if (!found) return null;
            
            // Reconstruir camino desde end hasta start
            var path = new List<int>();
            int node = end;
            while (node != -1)
            {
                path.Add(node);
                node = parent[node];
            }
            
            path.Reverse();
            return path;
        }
        
        // ========================================
        // BÚSQUEDA EN PROFUNDIDAD (DFS)
        // ========================================
        
        /// <summary>
        /// DFS recursivo desde un nodo inicial.
        /// </summary>
        /// <exception cref="ArgumentException">Si el nodo inicial no existe en el grafo</exception>
        public List<int>? DFSRecursive(int start)
        {
            // Validación de caso límite: nodo inexistente
            if (!adjacencyList.ContainsKey(start))
                throw new ArgumentException($"El nodo {start} no existe en el grafo");
            
            var visited = new HashSet<int>();
            var result = new List<int>();
            
            DFSRecursiveHelper(start, visited, result);
            
            return result;
        }
        
        private void DFSRecursiveHelper(int node, HashSet<int> visited, List<int> result)
        {
            visited.Add(node);
            result.Add(node);
            
            if (adjacencyList.ContainsKey(node))
            {
                foreach (int neighbor in adjacencyList[node])
                {
                    if (!visited.Contains(neighbor))
                    {
                        DFSRecursiveHelper(neighbor, visited, result);
                    }
                }
            }
        }
        
        /// <summary>
        /// DFS iterativo usando pila explícita.
        /// Más seguro para grafos muy profundos (evita stack overflow).
        /// </summary>
        /// <exception cref="ArgumentException">Si el nodo inicial no existe en el grafo</exception>
        public List<int>? DFSIterative(int start)
        {
            // Validación de caso límite: nodo inexistente
            if (!adjacencyList.ContainsKey(start))
                throw new ArgumentException($"El nodo {start} no existe en el grafo");
            
            var visited = new HashSet<int>();
            var result = new List<int>();
            var stack = new Stack<int>();
            
            stack.Push(start);
            
            while (stack.Count > 0)
            {
                int current = stack.Pop();
                
                if (visited.Contains(current))
                    continue;
                
                visited.Add(current);
                result.Add(current);
                
                // Apilar vecinos en orden inverso para mantener orden alfabético
                if (adjacencyList.ContainsKey(current))
                {
                    var neighbors = adjacencyList[current].ToList();
                    neighbors.Reverse();
                    
                    foreach (int neighbor in neighbors)
                    {
                        if (!visited.Contains(neighbor))
                        {
                            stack.Push(neighbor);
                        }
                    }
                }
            }
            
            return result;
        }
        
        // ========================================
        // APLICACIONES AVANZADAS
        // ========================================
        
        /// <summary>
        /// Detecta si existe un ciclo en un grafo DIRIGIDO usando DFS.
        /// </summary>
        public bool HasCycleDirected()
        {
            var state = new Dictionary<int, NodeState>();
            
            // Inicializar todos los nodos como NO_VISITADO
            foreach (var node in adjacencyList.Keys)
            {
                state[node] = NodeState.NotVisited;
            }
            
            // Intentar DFS desde cada nodo no visitado
            foreach (var node in adjacencyList.Keys)
            {
                if (state[node] == NodeState.NotVisited)
                {
                    if (HasCycleDirectedDFS(node, state))
                        return true;
                }
            }
            
            return false;
        }
        
        private bool HasCycleDirectedDFS(int node, Dictionary<int, NodeState> state)
        {
            state[node] = NodeState.InProgress;
            
            if (adjacencyList.ContainsKey(node))
            {
                foreach (int neighbor in adjacencyList[node])
                {
                    if (state[neighbor] == NodeState.InProgress)
                        return true; // ¡Ciclo detectado!
                    
                    if (state[neighbor] == NodeState.NotVisited)
                    {
                        if (HasCycleDirectedDFS(neighbor, state))
                            return true;
                    }
                }
            }
            
            state[node] = NodeState.Completed;
            return false;
        }
        
        /// <summary>
        /// Realiza ordenamiento topológico en un grafo dirigido acíclico (DAG).
        /// Retorna null si el grafo tiene ciclos.
        /// </summary>
        public List<int>? TopologicalSort()
        {
            if (HasCycleDirected())
                return null; // No se puede hacer ordenamiento topológico con ciclos
            
            var visited = new HashSet<int>();
            var stack = new Stack<int>();
            
            foreach (var node in adjacencyList.Keys)
            {
                if (!visited.Contains(node))
                {
                    TopologicalSortDFS(node, visited, stack);
                }
            }
            
            return stack.ToList();
        }
        
        private void TopologicalSortDFS(int node, HashSet<int> visited, Stack<int> stack)
        {
            visited.Add(node);
            
            if (adjacencyList.ContainsKey(node))
            {
                foreach (int neighbor in adjacencyList[node])
                {
                    if (!visited.Contains(neighbor))
                    {
                        TopologicalSortDFS(neighbor, visited, stack);
                    }
                }
            }
            
            stack.Push(node); // Agregar después de procesar todos los vecinos
        }
        
        /// <summary>
        /// Encuentra todas las componentes conectadas en un grafo no dirigido.
        /// </summary>
        public List<List<int>> FindConnectedComponents()
        {
            var visited = new HashSet<int>();
            var components = new List<List<int>>();
            
            foreach (var node in adjacencyList.Keys)
            {
                if (!visited.Contains(node))
                {
                    var component = new List<int>();
                    DFSForComponent(node, visited, component);
                    components.Add(component);
                }
            }
            
            return components;
        }
        
        private void DFSForComponent(int node, HashSet<int> visited, List<int> component)
        {
            visited.Add(node);
            component.Add(node);
            
            if (adjacencyList.ContainsKey(node))
            {
                foreach (int neighbor in adjacencyList[node])
                {
                    if (!visited.Contains(neighbor))
                    {
                        DFSForComponent(neighbor, visited, component);
                    }
                }
            }
        }
    }
    
    /// <summary>
    /// Estados de nodo para detección de ciclos en grafos dirigidos.
    /// </summary>
    public enum NodeState
    {
        NotVisited,   // Nodo no explorado
        InProgress,   // Nodo en proceso (en pila de recursión)
        Completed     // Nodo completamente procesado
    }
}