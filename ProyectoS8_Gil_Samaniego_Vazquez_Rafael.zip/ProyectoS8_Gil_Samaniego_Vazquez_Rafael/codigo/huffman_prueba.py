from huffman import Huffman

# ---------------------------------------
# Función: guardar un .huff eficiente
# ---------------------------------------
def compress_file(input_path, output_path):
    # Leer texto original
    with open(input_path, "r", encoding="utf-8") as f:
        texto = f.read()

    # Crear huffman
    h = Huffman()
    h.construir_arbol(texto)

    # Codificar texto
    tabla, bits = h.codificar(texto)

    # Convertir bits → bytes compactos
    data_bytes = Huffman.bits_a_bytes(bits)

    tabla_str = "\n".join(f"{c}:{tabla[c]}" for c in tabla)

    tabla_bytes = tabla_str.encode("utf-8")
    tabla_size = len(tabla_bytes).to_bytes(4, "big")

    with open(output_path, "wb") as f:
        f.write(tabla_size)
        f.write(tabla_bytes)
        f.write(data_bytes)


# ---------------------------------------
# Función: leer un .huff eficiente
# ---------------------------------------
def decompress_file(input_path, output_path):
    print("Descomprimiendo archivo...")

    # Abrir en modo BINARIO
    with open(input_path, "rb") as f:
        contenido = f.read()

    # Separar diccionario y datos binarios usando el delimitador \n\n
    try:
        indice = contenido.index(b"\n\n")
    except ValueError:
        print("❌ Error: archivo .huff sin diccionario válido.")
        return

    diccionario_bin = contenido[:indice].decode("utf-8", errors="ignore")
    datos_binarios = contenido[indice + 2:]  # saltar "\n\n"

    # Reconstruir diccionario invertido
    reverse_codes = {}
    for linea in diccionario_bin.split("\n"):
        if ":" not in linea:
            continue
        char, code = linea.split(":", 1)
        reverse_codes[code] = char

    # Convertir contenido binario a string de bits
    bitstring = ""
    for byte in datos_binarios:
        bitstring += f"{byte:08b}"

    # Decodificar
    decoded_text = ""
    buffer = ""

    for bit in bitstring:
        buffer += bit
        if buffer in reverse_codes:
            decoded_text += reverse_codes[buffer]
            buffer = ""

    # Guardar resultado (texto original)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(decoded_text)

    print(f"✔ Archivo descomprimido guardado como: {output_path}")
