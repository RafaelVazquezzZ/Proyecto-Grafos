# main.py
import os
import time
from bst import BSTIndex
from huffman_prueba import compress_file, decompress_file

TEXTFILE = "input.txt"        # archivo original
COMPRESSED = "input.huff"     # archivo comprimido
DECOMPRESSED = "input_decompressed.txt"   # archivo descomprimido

# ---------------------------------------------------------
# Construcción de índice (BST)
# ---------------------------------------------------------
def construir_indice(archivo):
    index = BSTIndex()
    with open(archivo, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            palabra = ""
            col = 1
            for i, ch in enumerate(line):
                if ch.isalnum():
                    palabra += ch
                else:
                    if palabra:
                        index.insertar_pos(palabra.lower(), lineno, col)
                        palabra = ""
                    col = i + 2  # columna aproximada
            if palabra:
                index.insertar_pos(palabra.lower(), lineno, col)
    return index


# ---------------------------------------------------------
# Mostrar contexto de búsqueda
# ---------------------------------------------------------
def mostrar_contexto(archivo, posiciones, radio=1):
    with open(archivo, "r", encoding="utf-8") as f:
        lineas = f.readlines()

    mostradas = set()

    for linea, col in posiciones:
        if linea in mostradas:
            continue
        mostradas.add(linea)

        print(f"\n--- Contexto (línea {linea}) ---")
        inicio = max(1, linea - radio)
        fin = min(len(lineas), linea + radio)

        for i in range(inicio, fin + 1):
            prefix = ">" if i == linea else " "
            print(f"{prefix} {i}: {lineas[i-1].rstrip()}")


# ---------------------------------------------------------
# Menú principal
# ---------------------------------------------------------
def menu():
    index = None

    while True:
        print("\n===== Proyecto Semana 8 Estructuras de Datos Arbóreas Especializadas =====")
        print("1. Construir índice del archivo input.txt")
        print("2. Buscar palabra en el índice")
        print("3. Comprimir archivo con Huffman")
        print("4. Descomprimir archivo huff")
        print("5. Ver estadísticas de compresión")
        print("6. Salir")

        opcion = input("Opción: ")

        # Opción 1: Construir índice
        if opcion == "1":
            if not os.path.exists(TEXTFILE):
                print("No existe input.txt")
                continue

            print("\nConstruyendo índice...")
            t0 = time.time()
            index = construir_indice(TEXTFILE)
            t1 = time.time()

            print("✔ Índice construido.")
            print(f"Palabras indexadas (nodos del BST): {len(index.inorden())}")
            print(f"Tiempo: {t1 - t0:.3f} s")

        # Opción 2: Buscar palabra
       
        elif opcion == "2":
            if index is None:
                print("❌ Debes construir el índice primero (opción 1)")
                continue

            palabra = input("Palabra a buscar: ").strip().lower()
            posiciones = index.buscar(palabra)

            if not posiciones:
                print("No se encontró esa palabra.")
            else:
                print(f"\n✔ Encontrada en {len(posiciones)} posiciones.")
                mostrar_contexto(TEXTFILE, posiciones)

        # Opción 3: Comprimir archivo
        elif opcion == "3":
            if not os.path.exists(TEXTFILE):
                print(" No existe input.txt")
                continue

            print("Comprimiendo archivo...")
            compress_file(TEXTFILE, COMPRESSED)
            print("✔ Archivo comprimido como:", COMPRESSED)

        # Opción 4: Descomprimir archivo
        
        elif opcion == "4":
            if not os.path.exists(COMPRESSED):
                print(" No existe input.huff")
                continue

            print("Descomprimiendo archivo...")
            decompress_file(COMPRESSED, DECOMPRESSED)
            print("✔ Archivo descomprimido como:", DECOMPRESSED)

        # Opción 5: Estadísticas
        elif opcion == "5":
            if not os.path.exists(TEXTFILE) or not os.path.exists(COMPRESSED):
                print(" Asegúrate de comprimir primero (opción 3)")
                continue

            size_original = os.path.getsize(TEXTFILE)
            size_comprimido = os.path.getsize(COMPRESSED)

            print("\n===== Estadísticas =====")
            print(f"Tamaño original:   {size_original} bytes")
            print(f"Tamaño comprimido: {size_comprimido} bytes")
            print(f"Ratio: {size_comprimido/size_original:.3f}")

        # Salir
        elif opcion == "6":
            break

        else:
            print("Opción inválida.")


if __name__ == "__main__":
    menu()
