class NodoIndex:
    def __init__(self, palabra):
        self.palabra = palabra
        self.posiciones = []      # lista de (linea, columna)
        self.izq = None
        self.der = None


class BSTIndex:
    """
    Árbol BST especializado para índice de palabras.
    Guarda:
      - palabra
      - lista de posiciones donde aparece
    """

    def __init__(self):
        self.raiz = None

    # Insertar palabra con posición
    def insertar_pos(self, palabra, linea, columna):
        self.raiz = self._insertar_rec(self.raiz, palabra, linea, columna)

    def _insertar_rec(self, nodo, palabra, linea, columna):
        if nodo is None:
            nodo = NodoIndex(palabra)
            nodo.posiciones.append((linea, columna))
            return nodo

        if palabra < nodo.palabra:
            nodo.izq = self._insertar_rec(nodo.izq, palabra, linea, columna)
        elif palabra > nodo.palabra:
            nodo.der = self._insertar_rec(nodo.der, palabra, linea, columna)
        else:
            # palabra repetida → solo agregas una posición más
            nodo.posiciones.append((linea, columna))

        return nodo

    # Buscar palabra en el índice
    def buscar(self, palabra):
        nodo = self._buscar_rec(self.raiz, palabra)
        if nodo:
            return nodo.posiciones
        return None

    def _buscar_rec(self, nodo, palabra):
        if nodo is None:
            return None

        if palabra == nodo.palabra:
            return nodo

        if palabra < nodo.palabra:
            return self._buscar_rec(nodo.izq, palabra)
        else:
            return self._buscar_rec(nodo.der, palabra)

    # Recorrido para depurar
    def inorden(self):
        res = []
        self._inorden_rec(self.raiz, res)
        return res

    def _inorden_rec(self, nodo, res):
        if nodo:
            self._inorden_rec(nodo.izq, res)
            res.append((nodo.palabra, nodo.posiciones))
            self._inorden_rec(nodo.der, res)
