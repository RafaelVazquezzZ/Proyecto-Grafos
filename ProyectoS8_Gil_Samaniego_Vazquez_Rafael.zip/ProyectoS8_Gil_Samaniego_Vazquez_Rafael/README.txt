Semana 8 Grafos

- Alumno: Gil Samaniego Vázquez Rafael
- Módulo: Estructuras de Datos Avanzadas

INSTRUCCIONES DE EJECUCIÓN

El archivo principal del proyecto es main.py, el cual construye el índice basado en un árbol BST para localizar palabras dentro del archivo de texto y ejecuta el módulo de compresión con el algoritmo de Huffman para generar el archivo comprimido .huff.

Además, los módulos bst.py, avl.py (opcional para comparación) y huffman.py contienen las implementaciones completas de las estructuras utilizadas.

El proyecto permite:

Construir un índice de palabras con línea y columna.

Buscar cualquier palabra y mostrar el contexto donde aparece.

Comprimir el archivo de entrada usando Huffman.

Descomprimirlo y validar que coincida con el original.

Mostrar estadísticas de compresión.

==================================================
EJECUCIÓN DEL PROYECTO (Python)
==================================================
1- En la terminal posicionarse en la carpeta código (cd codigo).

2- Ejecutar el archivo "main.py" (Python main.py).

3- (Opcional) Si se desea ejecutar un archivo individual ejecutar en terminal "Python 'Nombre_Del_Archivo.py'".
 