PROYECTO: Validación de Secuencias Gráficas - Semana 4
Alumno: Gil Samaniego Vázquez Rafael

Ejecución:
1. dotnet build
2. dotnet run

Archivos principales:
- codigo/Graph.cs
- codigo/GraphValidator.cs
- codigo/Program.cs
- codigo/havel_hakimi.py
- datos/edges_directed.txt
- datos/edges_undirected.txt
