﻿using System;
using System.Collections.Generic;
using System.Linq; // Necesario para .ToList()

namespace ProyectoS4
{
    class Program
    {
        // Helper para imprimir la matriz de forma legible (Necesario para Ejercicio 5)
        public static void PrintMatrix(double[,] matrix, List<string> vertices)
        {
            int n = matrix.GetLength(0);
            
            // Encabezado
            Console.Write("     ");
            foreach (var v in vertices) Console.Write($"{v, -4}");
            Console.WriteLine();

            for (int i = 0; i < n; i++)
            {
                Console.Write($"{vertices[i], -4} ");
                for (int j = 0; j < n; j++)
                {
                    // Imprime 1 si hay arista, 0 si no (para mejor legibilidad)
                    Console.Write($"{(matrix[i, j] > 0 ? 1 : 0), -4}"); 
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            // ... (Código de inicialización de la Semana 3, si existe)

            // 🚨 EJERCICIOS 3, 4 Y 5 INICIAN AQUÍ
            Console.WriteLine("\n=== PRUEBAS DE VALIDACIÓN Y PROPIEDADES (Semana 4) ===");
            
            // --- 1. EJERCICIO 3: Cargar y Extraer Secuencia ---
            // Carga el grafo no dirigido para Havel-Hakimi
            var cityGraph = Graph<string>.LoadFromFile(@"..\datos\edges_directed.txt"); 

            var extractedSeq = GraphValidator.ExtractDegreeSequence(cityGraph);
            Console.WriteLine($"\n[E3] Secuencia extraída: [{string.Join(",", extractedSeq)}]");
            Console.WriteLine($"[E3] ¿Es gráfica (Havel-Hakimi)? {GraphValidator.IsGraphicalSequence(extractedSeq)}");

            // --- 2. EJERCICIO 4: Validación de Consistencia y Conectividad ---
            Console.WriteLine("\n=== EJERCICIO 4: Validación de Consistencia ===");
            
            // La suma de grados debe ser par (chequeado en GraphValidator.ValidateConsistency)
            Console.WriteLine($"[E4] Consistencia (Suma Par): {GraphValidator.ValidateConsistency(cityGraph)}");
            
            // Nuevo chequeo de Conectividad
            Console.WriteLine($"[E4] Conectividad (¿es conexo?): {cityGraph.IsConnected()}");


            // --- 3. EJERCICIO 5: Matriz de Adyacencia ---
            Console.WriteLine("\n=== EJERCICIO 5: Matriz de Adyacencia ===");
            var matrix = cityGraph.GetAdjacencyMatrix();
            PrintMatrix(matrix, cityGraph.GetVertices().ToList());

            // --- 4. PRUEBAS OFICIALES DE SECUENCIAS (HAVEL–HAKIMI) ---
            Console.WriteLine("\n=== PRUEBAS OFICIALES HAVEL–HAKIMI ===");

            var testCases = new List<(List<int> seq, bool expected)>
            {
                (new List<int>{4,3,3,2,2,2,1,1}, true),
                (new List<int>{3,2,2,1}, true),
                (new List<int>{4,3,3,2,2,2}, true),
                (new List<int>{0,0,0,0}, true),
                (new List<int>{3,3,3,3}, true),
                (new List<int>{3,3,3,1}, false),
                (new List<int>{5,5,4,3,2,1}, false),
                (new List<int>{3,2,1}, false),
                (new List<int>{6,1,1,1,1,1,1}, false),
                (new List<int>{5,3,2,2,1}, false)
            };

            int i = 1;
            int correct = 0;

            foreach (var (seq, expected) in testCases)
            {
                bool result = GraphValidator.IsGraphicalSequence(seq);
                bool pass = result == expected;
                if (pass) correct++;
                Console.WriteLine($"Caso {i++,2}: [{string.Join(",", seq)}] → {result} (Esperado: {expected})");
            }

            Console.WriteLine($"\nResumen: {correct}/{testCases.Count} casos correctos.");

            //---5. EJERCICIO AVANZADO: SECUENCIAS BI-GRÁFICAS (KLEITMAN-WANG)
            Console.WriteLine("\n=== EJERCICIO AVANZADO: Kleitman-Wang (Grafo Dirigido) ===");

            // Caso 1: in=[2,1,1,0], out=[1,1,1,1]
            var in1 = new List<int> { 2, 1, 1, 0 };
            var out1 = new List<int> { 1, 1, 1, 1 };
            // Esperado: True (Suma In=4, Suma Out=4. Es bi-gráfica.)
            bool result1 = GraphValidator.IsBigraphicalSequence(in1, out1);
            Console.WriteLine($"[Avanzado 1] In: [{string.Join(",", in1)}], Out: [{string.Join(",", out1)}]");
            Console.WriteLine($"Resultado: {result1}. (Esperado: True)");


            // Caso 2: in=[2,2,1,1], out=[2,2,1,1]
            var in2 = new List<int> { 2, 2, 1, 1 };
            var out2 = new List<int> { 2, 2, 1, 1 };
            // Esperado: False (Suma In=6, Suma Out=6. Falla estructuralmente en la iteración.)
            bool result2 = GraphValidator.IsBigraphicalSequence(in2, out2);
            Console.WriteLine($"\n[Avanzado 2] In: [{string.Join(",", in2)}], Out: [{string.Join(",", out2)}]");
            Console.WriteLine($"Resultado: {result2}. (Esperado: False)");
        }
    }
}