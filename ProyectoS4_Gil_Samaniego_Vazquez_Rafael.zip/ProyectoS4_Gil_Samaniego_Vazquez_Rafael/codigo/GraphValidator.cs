using System;
using System.Collections.Generic;
using System.Linq;

namespace ProyectoS4
{
    public static class GraphValidator
    {
        /// <summary>
        /// Valida si una secuencia es gráfica usando Havel-Hakimi.
        /// </summary>
        public static bool IsGraphicalSequence(List<int> degrees)
        {
            var seq = new List<int>(degrees);

            while (seq.Any(d => d != 0))
            {
                seq.Sort((a, b) => b.CompareTo(a));
                int d = seq[0];
                seq.RemoveAt(0);

                if (d > seq.Count) return false;

                for (int i = 0; i < d; i++)
                {
                    seq[i]--;
                    if (seq[i] < 0) return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Valida la consistencia de un grafo simple (suma de grados par).
        /// </summary>
        public static bool ValidateConsistency(Graph<string> graph)
        {
            int totalDegree = graph.GetVertices().Sum(v => graph.GetOutDegree(v));
            return totalDegree % 2 == 0;
        }

        /// <summary>
        /// Extrae la secuencia de grados de salida de un grafo dirigido, en orden descendente.
        /// </summary>
        public static List<int> ExtractDegreeSequence(Graph<string> graph)
        {
            return graph.GetVertices()
                        .Select(v => graph.GetOutDegree(v))
                        .OrderByDescending(d => d)
                        .ToList();
        }

        /// <summary>
        /// Verificación estricta de secuencia bi-gráfica usando backtracking.
        /// </summary>
        public static bool IsBigraphicalSequence(List<int> inDegrees, List<int> outDegrees)
        {
            if (inDegrees == null || outDegrees == null) return false;
            if (inDegrees.Count != outDegrees.Count) return false;
            if (inDegrees.Sum() != outDegrees.Sum()) return false;

            int n = inDegrees.Count;

            bool Backtrack(int node, List<int> curIn, List<int> curOut)
            {
                if (node == n) return curIn.All(x => x == 0);

                if (curOut[node] == 0) return Backtrack(node + 1, curIn, curOut);

                // Intentar asignar aristas desde node a cualquier otro nodo válido
                for (int i = 0; i < n; i++)
                {
                    if (i == node) continue; // no lazos
                    if (curOut[node] > 0 && curIn[i] > 0)
                    {
                        curOut[node]--;
                        curIn[i]--;

                        if (Backtrack(node, curIn, curOut))
                            return true;

                        // Deshacer cambios
                        curOut[node]++;
                        curIn[i]++;
                    }
                }

                return false;
            }

            return Backtrack(0, new List<int>(inDegrees), new List<int>(outDegrees));
        }
    }
}
