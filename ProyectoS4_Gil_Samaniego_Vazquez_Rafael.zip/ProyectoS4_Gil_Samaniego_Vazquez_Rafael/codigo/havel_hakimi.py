from typing import List

def is_graphical_sequence(degrees: List[int]) -> bool:
    """
    Valida secuencia gráfica con Havel-Hakimi.
    Complejidad: O(n² log n) por reordenamiento en cada iteración.
    """
    if not degrees:
        return True
    
    # Crear copia para no modificar original
    seq = sorted(degrees, reverse=True)
    
    # Verificar suma par y máx grado
    total_sum = sum(seq)
    if total_sum % 2 != 0 or seq[0] >= len(seq):
        return False
    
    while seq:
        d1 = seq.pop(0)
        
        if d1 == 0:
            return True
        
        if d1 > len(seq):
            return False
        
        # Restar 1 de los siguientes d1
        for i in range(d1):
            seq[i] -= 1
            if seq[i] < 0:
                return False
        
        # CRÍTICO: Reordenar después de modificar
        seq.sort(reverse=True)
    
    return True

def validate_consistency(graph) -> bool:
    """
    Verifica consistencia: suma de grados debe ser par en grafo no dirigido.
    Nota: Para grafos grandes, optimiza usando in_degree() directamente.
    """
    vertices = list(graph.adj.keys())
    total_degree = sum(len(graph.adj[v]) for v in vertices)
    # En grafo no dirigido, suma de grados = 2 * |aristas|
    return total_degree % 2 == 0

def extract_degree_sequence(graph) -> List[int]:
    """
    Extrae secuencia de grados del grafo de Semana 3.
    Útil para validar el mapa urbano como secuencia gráfica.
    
    Enlace directo con proyecto: usa esta función para extraer grados
    de tu mapa urbano y validar con is_graphical_sequence().
    """
    degrees = sorted([len(graph.adj[v]) for v in graph.adj.keys()], reverse=True)
    return degrees

# ═══════════════════════════════════════════════════════════
# Script de prueba ejecutable (copia y ejecuta en tu entorno)
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== Pruebas de Havel-Hakimi ===\n")
    
    # Casos válido
    seq_valid = [4, 3, 3, 2, 2, 2, 1, 1]
    print(f"Caso 1: {seq_valid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_valid) else '✖ No Gráfica'}\n")
    seq_valid = [3, 2, 2, 1]
    print(f"Caso 2: {seq_valid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_valid) else '✖ No Gráfica'}\n")
    seq_valid = [4, 3, 3, 2, 2, 2]
    print(f"Caso 3: {seq_valid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_valid) else '✖ No Gráfica'}\n")
    seq_valid = [0, 0, 0, 0]
    print(f"Caso 4: {seq_valid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_valid) else '✖ No Gráfica'}\n")
    seq_valid = [3, 3, 3, 3]
    print(f"Caso 5: {seq_valid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_valid) else '✖ No Gráfica'}\n")

    
    # Caso NO válido (corregido)
    seq_invalid = [3, 3, 3, 1]
    print(f"Caso 6: {seq_invalid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_invalid) else '✖ No Gráfica'}\n")
    seq_invalid = [5, 5, 4, 3, 2, 1]
    print(f"Caso 7: {seq_invalid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_invalid) else '✖ No Gráfica'}\n")
    seq_invalid = [3, 2, 1]
    print(f"Caso 8: {seq_invalid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_invalid) else '✖ No Gráfica'}\n")
    seq_invalid = [6, 1, 1, 1, 1, 1, 1]
    print(f"Caso 9: {seq_invalid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_invalid) else '✖ No Gráfica'}\n")
    seq_invalid = [5, 3, 2, 2, 1]
    print(f"Caso 10: {seq_invalid}")
    print(f"Resultado: {'✓ Gráfica' if is_graphical_sequence(seq_invalid) else '✖ No Gráfica'}\n")
    
    # Conectar con Semana 3 (requiere tu código de Semana 3)
    # Ejemplo de extracción de secuencia:
    # from grafo import load_graph
    # graph = load_graph("ciudad.txt")
    # extracted_seq = extract_degree_sequence(graph)
    # print(f"Secuencia del mapa urbano: {extracted_seq}")
    # print(f"¿Es gráfica? {is_graphical_sequence(extracted_seq)}")
    # print(f"¿Consistente? {validate_consistency(graph)}")