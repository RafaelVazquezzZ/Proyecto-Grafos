using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ProyectoS4
{
    public class Graph<T> where T : IComparable
    {
        private readonly Dictionary<T, List<(T to, double weight)>> adjacencyList = new Dictionary<T, List<(T to, double weight)>>();

        public void AddVertex(T vertex)
        {
            if (!adjacencyList.ContainsKey(vertex))
                adjacencyList[vertex] = new List<(T, double)>();
        }

        public void AddEdge(T from, T to, double weight = 1.0, bool isDirected = true)
        {
            AddVertex(from);
            AddVertex(to);

            // CS8602 Corrección: AddVertex asegura que la clave existe
            adjacencyList[from].Add((to, weight));

            if (!isDirected)
                adjacencyList[to].Add((from, weight));
        }

        // Método para obtener la carpeta "datos" (Ajustado para eliminar CS8602/CS8600)
        private string GetDataFolder()
        {
            // Usa el operador de fusión nula para evitar errores si GetParent devuelve null (CS8602/CS8600)
            string parentFolder = Directory.GetParent(Directory.GetCurrentDirectory())?.FullName ?? Directory.GetCurrentDirectory();
            string folder = Path.Combine(parentFolder, "datos");
            Directory.CreateDirectory(folder);
            return folder;
        }

        public void ExportToFile(string filename, bool includeWeights = true, bool deduplicateUndirected = false)
        {
            try
            {
                if (!Path.IsPathRooted(filename))
                    filename = Path.Combine(GetDataFolder(), filename);

                using var writer = new StreamWriter(filename);
                var processedEdges = new HashSet<string>();

                foreach (var vertex in adjacencyList.Keys.OrderBy(v => v))
                {
                    // CS8602 Corrección: La clave vertex existe, pero T podría ser nulo si no se usa string.
                    var vertexStr = vertex?.ToString() ?? ""; 
                    
                    foreach (var (neighbor, weight) in adjacencyList[vertex])
                    {
                        var neighborStr = neighbor?.ToString() ?? "";

                        if (deduplicateUndirected)
                        {
                            var edgeKey = vertex.CompareTo(neighbor) <= 0
                                ? $"{vertexStr}→{neighborStr}"
                                : $"{neighborStr}→{vertexStr}";

                            if (!processedEdges.Add(edgeKey))
                                continue;
                        }

                        var line = includeWeights
                            ? $"{vertex} {neighbor} {weight:F1}"
                            : $"{vertex} {neighbor}";
                        writer.WriteLine(line);
                    }
                }
                Console.WriteLine($"✅ Archivo '{filename}' exportado exitosamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error al exportar archivo: {ex.Message}");
            }
        }

        // 🛠️ FUNCIÓN CORREGIDA Y ROBUSTA PARA LA RUTA (Ejercicio 3)
        public static Graph<string> LoadFromFile(string filename)
        {
            var graph = new Graph<string>();
            string fullPath = "";
            string currentSearchDir = Directory.GetCurrentDirectory();
            
            // Búsqueda iterativa subiendo hasta 4 niveles para encontrar la carpeta 'datos'
            for (int i = 0; i < 4; i++)
            {
                string potentialPath = Path.Combine(currentSearchDir, "datos", filename);
                
                if (File.Exists(potentialPath))
                {
                    fullPath = potentialPath;
                    break;
                }
                
                // Sube al directorio padre (Uso del operador de fusión nula para evitar CS8602)
                currentSearchDir = Directory.GetParent(currentSearchDir)?.FullName;
                if (currentSearchDir == null) break;
            }

            if (!File.Exists(fullPath))
            {
                Console.WriteLine($"❌ Error: Archivo de datos no encontrado. Buscado: {filename}");
                return graph;
            }

            // --- 2. Determinar Direccionalidad ---
            bool isDirected = filename.Contains("directed");
            Console.WriteLine($"✅ Cargando grafo {(isDirected ? "DIRIGIDO" : "NO DIRIGIDO")} desde: {filename}");

            // --- 3. Leer y Construir el Grafo ---
            try
            {
                var lines = File.ReadAllLines(fullPath);
                foreach (var line in lines)
                {
                    var parts = line.Trim().Split(new char[] {' ', '\t'}, StringSplitOptions.RemoveEmptyEntries);
                    
                    if (parts.Length < 3) continue; 

                    string from = parts[0];
                    string to = parts[1];
                    
                    if (double.TryParse(parts[2], System.Globalization.NumberStyles.Any, 
                                            System.Globalization.CultureInfo.InvariantCulture, out double weight))
                    {
                        graph.AddEdge(from, to, weight, isDirected);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error durante la lectura o construcción del grafo: {ex.Message}");
            }

            return graph;
        }

        public IEnumerable<T> GetVertices() => adjacencyList.Keys;

        public IEnumerable<(T neighbor, double weight)> GetNeighbors(T vertex)
        {
            return adjacencyList.TryGetValue(vertex, out var neighbors)
                ? neighbors
                : Enumerable.Empty<(T, double)>();
        }

        public bool HasEdge(T from, T to)
        {
            return adjacencyList.TryGetValue(from, out var neighbors) &&
                         neighbors.Any(edge => EqualityComparer<T>.Default.Equals(edge.to, to));
        }

        public int GetOutDegree(T vertex)
        {
            return adjacencyList.TryGetValue(vertex, out var neighbors) ? neighbors.Count : 0;
        }

        public int GetInDegree(T vertex)
        {
            return adjacencyList.Values
                .SelectMany(neighbors => neighbors)
                .Count(edge => EqualityComparer<T>.Default.Equals(edge.to, vertex));
        }

        // 🛠️ MÉTODO AÑADIDO: Implementación para Conectividad (Ejercicio 4)
        public bool IsConnected()
        {
            if (adjacencyList.Count <= 1) return true;

            T startVertex;
            try
            {
                // Busca el primer vértice con aristas para empezar el recorrido
                startVertex = adjacencyList.Keys.First(v => GetOutDegree(v) > 0 || GetInDegree(v) > 0);
            }
            catch (InvalidOperationException)
            {
                // Si todos los vértices tienen grado 0, solo es conexo si hay uno.
                return adjacencyList.Count == 1;
            }

            var visited = new HashSet<T>();
            var stack = new Stack<T>(); // Usamos DFS

            stack.Push(startVertex);
            visited.Add(startVertex);

            while (stack.Count > 0)
            {
                T current = stack.Pop();
                
                // Recorre vecinos de salida
                foreach (var (neighbor, weight) in GetNeighbors(current))
                {
                    if (!visited.Contains(neighbor))
                    {
                        visited.Add(neighbor);
                        stack.Push(neighbor);
                    }
                }
            }
            
            // Verifica que el número de vértices visitados sea igual al total de vértices
            return visited.Count == adjacencyList.Count;
        }


        // Implementación para Matriz de Adyacencia (Ejercicio 5)
        public double[,] GetAdjacencyMatrix()
        {
            var vertices = GetVertices().ToList();
            int n = vertices.Count;
            var matrix = new double[n, n];
            var indexMap = new Dictionary<T, int>();

            // 1. Crear mapeo de Vértice a Índice
            for (int i = 0; i < n; i++)
            {
                indexMap[vertices[i]] = i;
            }

            // 2. Llenar la matriz
            foreach (var vertex in vertices)
            {
                int i = indexMap[vertex];
                foreach (var (neighbor, weight) in GetNeighbors(vertex))
                {
                    if (indexMap.ContainsKey(neighbor))
                    {
                        int j = indexMap[neighbor];
                        matrix[i, j] = weight; 
                    }
                }
            }
            return matrix;
        }

        public void PrintGraph()
        {
            Console.WriteLine("=== Estructura del Grafo ===");
            foreach (var vertex in adjacencyList.Keys.OrderBy(v => v))
            {
                var neighbors = string.Join(", ",
                    adjacencyList[vertex].Select(edge => $"{edge.to}({edge.weight:F1})"));
                Console.WriteLine($"{vertex}: [{neighbors}]");
            }
        }
    }
}