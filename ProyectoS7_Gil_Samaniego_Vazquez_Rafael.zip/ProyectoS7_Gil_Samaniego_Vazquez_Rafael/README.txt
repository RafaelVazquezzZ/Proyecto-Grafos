Semana 7 Grafos

- Alumno: Gil Samaniego Vázquez Rafael
- Módulo: Estructuras de Datos Avanzadas

INSTRUCCIONES DE EJECUCIÓN

==================================================
EJECUCIÓN DEL PROYECTO (Python)
==================================================

El archivo principal del proyecto es 'main.py', el cual genera un grafo ponderado aleatorio y ejecuta los algoritmos de Prim y Kruskal para calcular el Árbol de Expansión Mínima (MST).
Además, el archivo 'tiempos.py' ejecuta pruebas de rendimiento para comparar los tiempos de ambos algoritmos en grafos de diferentes tamaños.

PASOS PARA LA EJECUCIÓN:

1- Posicionarse en la terminal:
Abre tu terminal y navega hasta la carpeta donde se encuentran los archivos del proyecto (main.py, pruebas.py y tiempos.py).

2- Ejecutar el programa principal:
Escribe el siguiente comando y presiona Enter:
python main.py

Al correr main.py se mostrarán:
- La prueba rápida de que Prim y Krusal funcionan.

Al correr pruebas.py se mostraran:
- El número de nodos y aristas del grafo generado.
- El conjunto de aristas que forman el MST con Prim y su costo total.
- El conjunto de aristas que forman el MST con Kruskal y su costo total.
- Comparación de resultados entre ambos algoritmos.

Al correr tiempos.py se imprimirán:
- Los tiempos de ejecución de Prim y Kruskal para grafos pequeños, medianos y grandes.
- Las diferencias de rendimiento entre ambos algoritmos.