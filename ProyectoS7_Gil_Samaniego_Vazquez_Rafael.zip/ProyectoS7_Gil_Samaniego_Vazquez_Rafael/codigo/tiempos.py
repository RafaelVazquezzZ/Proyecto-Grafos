import time
from mst import GraphMST
import random

def medir_tiempos(n):

    g = GraphMST(n)

    # Rellenar el grafo con aristas aleatorias (densidad moderada)
    for u in range(n):
        for v in range(u+1, n):
            w = random.randint(1, 50)
            g.add_edge(u, v, w)

    start = time.time()
    g.prim_mst()
    t_prim = time.time() - start

    start = time.time()
    g.kruskal_mst()
    t_kruskal = time.time() - start

    return t_prim, t_kruskal


if __name__ == "__main__":
    tamanos = [10, 100, 500]


for t in tamanos:
    tp, tk = medir_tiempos(t)
    print(f"\nGrafo con {t} nodos:")
    print(f"Tiempo Prim: {tp:.6f} s")
    print(f"Tiempo Kruskal: {tk:.6f} s")

