from mst import GraphMST

def probar(nombre, edges):
    print(f"\n=== {nombre} ===")


    # Crear el grafo dinámicamente según los nodos usados
    max_node = max(max(u, v) for u, v, _ in edges)
    g = GraphMST(max_node + 1)

    # Agregar aristas
    for u, v, w in edges:
        g.add_edge(u, v, w)

    prim_edges, prim_cost = g.prim_mst()
    kruskal_edges, kruskal_cost = g.kruskal_mst()

    print("Prim:", prim_edges, "Costo:", prim_cost)
    print("Kruskal:", kruskal_edges, "Costo:", kruskal_cost)

# Grafos de prueba

g1 = [
(0,1,10),
(1,2,5),
(0,2,7),
]

g2 = [
(0,1,2),
(1,2,3),
(2,3,1),
(3,0,4),
]

g3 = [
(0,1,6),
(0,2,1),
(2,3,2),
(1,3,5),
(1,2,3),
]

g4 = [
(0,1,4),
(1,2,8),
(2,3,2),
(3,4,6),
(0,4,5),
]

g5 = [
(0,1,9),
(1,2,7),
(2,3,3),
(3,4,4),
(4,5,1),
(5,6,2),
(6,7,8),
(0,7,5),
]

if __name__ == "__main__":
    probar("Grafo 1", g1)
    probar("Grafo 2", g2)
    probar("Grafo 3", g3)
    probar("Grafo 4", g4)
    probar("Grafo 5", g5)
